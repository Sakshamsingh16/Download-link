== DooPlay ==
Contributors: Doothemes team
Requires at least: WordPress 5+
Tested up to: WordPress 5.4.1
Version: 2.4.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Copyright ==

DooPlay WordPress Theme, Copyright 2016-2020 Doothemes.com & themes.pe

== Documentation ==

https://dooplay.themes.pe

== Change Log ==

https://dooplay.themes.pe/changelog
